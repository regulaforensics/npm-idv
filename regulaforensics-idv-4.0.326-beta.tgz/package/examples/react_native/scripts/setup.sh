#!/usr/bin/env bash
set -e

npm install
npx expo prebuild --no-install
(cd ios && (pod install || (pod repo update && pod install)))

mkdir -p android/app/src/main/assets/Regula
mv android/app/src/main/res/raw/regula.license android/app/src/main/assets/Regula/
mv android/app/src/main/res/raw/db.dat android/app/src/main/assets/Regula/

grep -q 'buildFeatures { dataBinding true }' android/app/build.gradle ||
  printf '\n%s\n' 'android { buildFeatures { dataBinding true } }' >> android/app/build.gradle
