package com.regula.plugin.idv

import android.app.Activity
import android.content.Context
import android.util.Log
import org.apache.cordova.CallbackContext
import org.apache.cordova.CordovaPlugin
import org.apache.cordova.PluginResult
import org.json.JSONArray

val eventCallbackIds = mutableMapOf<String, String>()

lateinit var args: JSONArray
lateinit var binding: CordovaPlugin
val context: Context
    get() = binding.cordova.context
val activity: Activity
    get() = binding.cordova.activity

fun sendEvent(callbackId: String, data: Any? = "") {
    val pluginResult = when (data) {
        is Int -> PluginResult(PluginResult.Status.OK, data)
        is Boolean -> PluginResult(PluginResult.Status.OK, data)
        is Throwable -> PluginResult(PluginResult.Status.ERROR, data.message)
        else -> PluginResult(PluginResult.Status.OK, data.toSendable() as String?)
    }
    pluginResult.keepCallback = data !is Throwable
    binding.webView.sendPluginResult(pluginResult, eventCallbackIds[callbackId] ?: callbackId)
}

@Suppress("UNCHECKED_CAST")
fun <T> argsNullable(index: Int): T? = if (args.get(index).toString() != "null") {
    args.get(index) as T
} else null

class CDVIDV : CordovaPlugin() {
    init {
        binding = this
    }

    override fun execute(action: String, arguments: JSONArray, callbackContext: CallbackContext): Boolean {
        args = arguments
        val method = args.remove(0) as String
        if (method == "setEvent") eventCallbackIds[args(0)] = callbackContext.callbackId
        try {
            methodCall(method) { data: Any? -> sendEvent(callbackContext.callbackId, data) }
        } catch (error: Throwable) {
            Log.e("REGULA", "Caught an exception in \"$method\" function:", error)
            sendEvent(callbackContext.callbackId, Throwable("Unexpected error, check logs for details"))
        }
        return true
    }
}
